
 <link href="home_css/hover-min.css" rel="stylesheet">
<div class="container-fluid" style="min-height:70px!important;background:black;border-top:5px solid #4080BB; padding-top:7px!important;">
    <div class="row footer">
     <div class="col-lg-4 col-lg-offset-2" style=" height:80px;">ACM Student Chapter ISM Dhanbad © 2016 <br>All Rights Reserved </div>
        
 </div>
</div>
<style type="text/css">
.footer{
color: white;
text-align:center;
 font-family:Champagne;
 font-size: 20px;
}

@font-face {
    font-family:Champagne;
    src: url(home_css/fonts/Champagne.ttf);
}
</style>