#include<iostream>
#include<stdio.h>
using namespace std;
int arr[200050];
int n,k,a,b,c,r;
int hash[200050];
int main()
{
    int t,m,i;
    long long int j;
    scanf("%d",&t);
	while(t--)
	{
       scanf("%d%d",&n,&k);
       while(n>k) n-=(k+1);
       n+=(k+1);
       for(i=0;i<200050;i++)
          hash[i]=0;
       for(i=0;i<k;i++)
       {
       		scanf("%d",&arr[i]);
            if(arr[i]<200050)
               hash[arr[i]]++;
       }
       for(j=0;j<200050;j++)
       {
           if(hash[j]==0)
           {
               arr[k]=j;
               hash[j]++;
               j++;
               break;
           }
       }
       for(i=k+1;i<n;i++)
       {
           if(arr[i-k-1]<200050)
           {
                hash[arr[i-k-1]]--;
                if(arr[i-k-1]<=j && hash[arr[i-k-1]]==0)
                {
                   arr[i]=arr[i-k-1];
                   hash[arr[i-k-1]]++;
                }
                else
                {
                   for(  ;j<200050;j++)
                   {
                      if(hash[j]==0)
                      {   arr[i]=j;  hash[j]++; j++; break; }
                   }
                }
           }
           else
           {
                   for(  ;j<200050;j++)
                   {
                      if(hash[j]==0)
                      {   arr[i]=j;  hash[j]++; j++; break; }
                   }
           }
       }
       printf("%d\n",arr[n-1]);
    }
    return 0;
}
       

