#include<iostream>
using namespace std;
int arr[1000005];
int main()
{
	int i,n,m,x,y,k;
	scanf("%d%d",&n,&m);
	while(m--)
	{
		scanf("%d%d%d",&x,&y,&k);
		arr[x]+=k;
		arr[y+1]-=k;
	}
	int val=0;
	for(i=0;i<n;i++)
	{
		val+=arr[i];
		printf("%d\n",val);
	}
	return 0;
}


