#include<iostream>
using namespace std;
#define LIM 2015
int grundy[LIM][LIM];
int vis[LIM+10];
void pre()
{
	int i,j;
	for(j=1;j<LIM;j++) 
		grundy[0][j]=0;
	for(i=1;i<LIM;i++)
	{
		for(j=0;j<LIM+10;j++)
		   vis[j]=0;
		int mex=0;
		for(j=1;j<=i;j++)
		{
			vis[grundy[i-j][j]]=1;
			while(vis[mex]) 
				mex++;
			grundy[i][j]=mex;
		}
		for(j=i+1;j<LIM;j++) 
			grundy[i][j]=grundy[i][i];
	}
}

int main()
{
	pre();
	int t;
	scanf("%d",&t);
	while(t--)
	{
		int n,k,x,gr=0;
		scanf("%d%d",&n,&k);
		while(n--)
		{
			scanf("%d",&x);
			gr=gr^grundy[x][min(x,k)];
		}
		if(gr)
		  printf("Cartman\n");
		else
		  printf("Butters\n");
	}
	return 0;
}




