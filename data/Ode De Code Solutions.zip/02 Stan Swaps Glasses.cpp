#include<iostream>
using namespace std;
char arr[100005][25];
int pos[100005];
int main()
{
	int n,q;
	scanf("%d%d",&n,&q);
	int i,x,y,temp;
	for(i=1;i<=n;i++)
	   scanf("%s",arr[i]);
	for(i=1;i<=n;i++)
	   pos[i]=i;
	char query[20];
	while(q--)
	{
		scanf("%s",query);
		if(query[0]=='A')
		{
			scanf("%d",&x);
		    printf("%s\n",arr[pos[x]]);
		}
		else
		{
			scanf("%d%d",&x,&y);
			temp=pos[x]; pos[x]=pos[y]; pos[y]=temp;
		}
	}
	return 0;
}

