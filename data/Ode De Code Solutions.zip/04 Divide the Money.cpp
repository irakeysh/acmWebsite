#include<iostream>
using namespace std;
int arr[105];
int val[100005];
int ab(int x,int y)
{
	if(x-y<0)  return y-x;
	else return x-y;
}
int main()
{
	int i,n,j,sum=0;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
	   scanf("%d",&arr[i]);
	   sum+=arr[i];
	}
	val[0]=1;
	for(i=0;i<n;i++)
	{
		for(j=sum;j-arr[i]>=0;j--)
		   if(val[j-arr[i]]==1)
		      val[j]=1;
	}
	int x,ans=1000000;
	if(sum%2==1)
	{
		x=(sum/2)+1;
		for(i=0;  ;i++)
		{
			if(val[x-i]==1)
			{
			   ans=ab(sum-x+i,x-i);
			   break;
			}
			if(val[x+i]==1)
			{
				ans=ab(sum-x-i,x+i);
				break;
			}
		}
	}
	else
	{
		x=sum/2;
		for(i=0; ;i++)
		{
			if(val[x-i]==1)
			{
				ans=ab(sum-x+i,x-i);
				break;
			}
			if(val[x+i+1]==1)
			{
				ans=ab(sum-x-i-1,x+i+1);
				break;
			}
		}
	}
	printf("%d\n",ans);
	return 0;
}

