#include<iostream>
#include<algorithm>
using namespace std;
struct bul
{
    long long cst,prod;
    inline bool operator < (const bul &cpr) const
    {
        if (prod!=cpr.prod)
            return prod<cpr.prod;
        return cst<cpr.cst;
    }
};
bul bl[200005];
long long k[200005],ad[200005],poc[200005];
int cnt;
int n;
long long s;
int stak[200005];
int sze;
int main()
{
    scanf("%d",&n);
    scanf("%lld",&s);
    for (int i=1; i<=n; i++)
        scanf("%lld%lld",&bl[i].prod,&bl[i].cst);
    sort(bl+1,bl+1+n);
    cnt=0;
    int pocni=n;
    while (bl[pocni].cst)
        pocni--;
    for (int it=pocni; it<=n; it++)
    {
        if (cnt==0)
        {
            if (bl[it].cst>0)
                continue;
            cnt=1;
            k[cnt]=bl[it].prod;
            ad[cnt]=0;
            poc[cnt]=0;
        }
        else
        {
            if (bl[it].prod<=k[cnt])
                continue;
            int top,bot,tr;
            top=cnt;
            bot=1;
            while (top>bot)
            {
                tr=(top+bot)/2;
                if (ad[tr]+k[tr]*(poc[tr+1]-1)<bl[it].cst)
                    bot=tr+1;
                else
                    top=tr;
            }
            long long tmn;
            tmn=(bl[it].cst-ad[top]+k[top]-1)/k[top];
            long long nad;
            nad=ad[top]+k[top]*tmn-bl[it].cst-bl[it].prod*tmn;
            while (cnt>0 && nad+bl[it].prod*poc[cnt]>ad[cnt]+k[cnt]*poc[cnt])
                cnt--;
            cnt++;
            k[cnt]=bl[it].prod;
            ad[cnt]=nad;
            if (cnt==0)
                poc[cnt]=0;
            else
                poc[cnt]=(ad[cnt-1]-ad[cnt]+k[cnt]-k[cnt-1]-1)/(k[cnt]-k[cnt-1]);
            if (poc[cnt]>s)
                cnt--;
        }
    }
    long long mn=(s-ad[1]+k[1]-1)/k[1];
    for (int i=2; i<=cnt; i++)
        mn=min(mn,(s-ad[i]+k[i]-1)/k[i]);
    printf("%lld\n",mn);
}

